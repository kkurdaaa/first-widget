import 'package:flutter/material.dart';

void main() {
  runApp(
    MaterialApp(
      title: 'Assignment',
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Assignment')
          ),
          body: const Center(
            child: Text('Hello Kurdistan!'),
          ),
          )
    )
  );
}