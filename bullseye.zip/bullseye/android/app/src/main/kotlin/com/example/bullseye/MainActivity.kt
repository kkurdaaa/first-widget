package com.example.bullseye

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
